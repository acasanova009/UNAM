package mx.unam.ciencias.edd;

import java.util.Random;
import java.text.NumberFormat;

/**
 * Proyecto 2: Diccionarios.
 */
public class Proyecto2 {

    public static void main(String[] args) {
        
        
        
        int total = 8;
        
        if(args.length == 1)
            try{
                total = Integer.parseInt(args[0]);}
        catch(NumberFormatException e){
            total = 4;}
        Random random = new Random();
        
        ArbolBinario<Integer>ab;
        
        String head = "<!DOCTYPE html> \n <html> \n <body>\n";
        

        ab = new ArbolBinarioCompleto<Integer>();
        for (int i = 0; i < total; i++)
            ab.agrega(i);
        
        

        head+= ab.generaScalableVectorGraphics();

        ab = new ArbolBinarioOrdenado<Integer>();
        for (int i = 0; i < total/4; i++)
            ab.agrega(random.nextInt(total/4));
        head+= ab.generaScalableVectorGraphics();

        
        ab = new ArbolRojinegro<Integer>();
        for (int i = 0; i < total; i++)
            ab.agrega(random.nextInt(total));
        
        head+= ab.generaScalableVectorGraphics();
        
        
        
        Lista<Integer> l=  new Lista<Integer>();
        for (int i = 0; i < total/4; i++)
            l.agregaInicio(i);
        
        head+= l.generaScalableVectorGraphics();
        
        Grafica<Integer> grafica = new Grafica<Integer>();
        
        for (int i = 0; i < total; i++)
            grafica.agrega(i);
        for (int i = 0; i < total; i++) {
            for (int j = i+1; j < total; j++)
                grafica.conecta(i, j);
            
        }
        head+=grafica.generaScalableVectorGraphics();

        

        
        head+="</body>\n</html>\n";

        System.out.println(head);

        
        
    
    }
}
